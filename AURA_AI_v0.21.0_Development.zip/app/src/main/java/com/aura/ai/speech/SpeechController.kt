package com.aura.ai.speech

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Persian-first speech output. Recognition is delegated to Android's selected recognizer. */
class SpeechController(context: Context) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = TextToSpeech(app, this)
    @Volatile private var ready = false
    @Volatile private var languageAvailable = false

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) return
        val af = tts?.setLanguage(Locale("fa", "AF")) ?: TextToSpeech.LANG_NOT_SUPPORTED
        val ir = if (af < TextToSpeech.LANG_AVAILABLE) tts?.setLanguage(Locale("fa", "IR")) ?: TextToSpeech.LANG_NOT_SUPPORTED else af
        languageAvailable = ir >= TextToSpeech.LANG_AVAILABLE
    }

    fun isReady(): Boolean = ready
    fun supportsPersian(): Boolean = ready && languageAvailable

    fun speak(text: String): Boolean {
        val clean = text.trim().take(4000)
        if (!supportsPersian() || clean.isBlank()) return false
        return tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "aura_reply") == TextToSpeech.SUCCESS
    }

    fun stop() { tts?.stop() }
    fun shutdown() { ready = false; languageAvailable = false; tts?.stop(); tts?.shutdown(); tts = null }

    fun recognitionIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-AF")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fa-AF")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "با AURA صحبت کن")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
}
