package com.aura.ai.bubble

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.aura.ai.MainActivity

class BubbleService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null

    override fun onCreate() {
        super.onCreate()
        val channel = "aura_running"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channel, "AURA AI", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(this, 2, Intent(this, BubbleService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("AURA AI فعال است")
            .setContentText("برای بازکردن دستیار، حباب را لمس کن.")
            .addAction(Notification.Action.Builder(null, "توقف", stop).build()).build()
        startForeground(41, notification)
        if (Settings.canDrawOverlays(this)) showBubble()
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            colors = intArrayOf(Color.rgb(120, 48, 230), Color.rgb(18, 24, 58), Color.rgb(12, 13, 28))
            setStroke(dp(2), Color.rgb(255, 198, 83))
        }
        val view = TextView(this).apply {
            text = "A"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
            background = ring
            elevation = dp(12).toFloat()
            contentDescription = "حباب شناور AURA AI"
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(dp(60), dp(60), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(18); y = dp(240)
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragged = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; dragged = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) dragged = true
                    params.x = (startX - dx).coerceAtLeast(0); params.y = (startY + dy).coerceAtLeast(0)
                    try { windowManager?.updateViewLayout(view, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    true
                }
                else -> true
            }
        }
        windowManager?.addView(view, params)
        bubble = view
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (intent?.action == "STOP") stopSelf(); return START_NOT_STICKY }
    override fun onDestroy() { bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }; bubble = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
