package com.aura.ai.tasks

import org.json.JSONObject
import java.util.UUID

/** Strict local validator for AI-proposed UI actions. AI output is always untrusted input. */
object AiTaskPlanner {
    fun parse(request: String, rawJson: String): TaskPlan {
        val clean = rawJson.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (request.isBlank()) return TaskPlan(request, emptyList(), "درخواست خالی است.")
        TaskRiskPolicy.blockedRequestReason(request)?.let { return TaskPlan(request, emptyList(), it) }
        return try {
            val root = JSONObject(clean)
            if (root.optBoolean("needs_clarification", false)) {
                return TaskPlan(request, emptyList(), root.optString("clarification", "برای برنامه‌ریزی به توضیح بیشتری نیاز است."))
            }
            val array = root.optJSONArray("steps") ?: return TaskPlan(request, emptyList(), "پاسخ برنامه‌ریز ساختار معتبر ندارد.")
            if (array.length() !in 1..5) return TaskPlan(request, emptyList(), "برنامه باید بین ۱ تا ۵ مرحله داشته باشد.")
            val steps = mutableListOf<TaskStep>()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: return TaskPlan(request, emptyList(), "مرحله ${i + 1} معتبر نیست.")
                val action = when (item.optString("action").uppercase()) {
                    "BACK" -> TaskAction.BACK
                    "SCROLL" -> TaskAction.SCROLL
                    "CLICK_TEXT" -> TaskAction.CLICK_TEXT
                    "TYPE_TEXT" -> TaskAction.TYPE_TEXT
                    else -> return TaskPlan(request, emptyList(), "نوع عملیات مرحله ${i + 1} پشتیبانی نمی‌شود.")
                }
                val argument = item.optString("argument").trim()
                if (argument.length > 500) return TaskPlan(request, emptyList(), "آرگومان مرحله ${i + 1} بیش از حد طولانی است.")
                val description = item.optString("description").ifBlank { "مرحله ${i + 1}" }.take(140)
                when (action) {
                    TaskAction.CLICK_TEXT -> {
                        if (argument.isBlank()) return TaskPlan(request, emptyList(), "نام عنصر مرحله ${i + 1} خالی است.")
                        TaskRiskPolicy.blockedClickReason(argument)?.let { return TaskPlan(request, emptyList(), it) }
                    }
                    TaskAction.TYPE_TEXT -> {
                        if (argument.isBlank() || TaskRiskPolicy.isSensitiveText(argument)) return TaskPlan(request, emptyList(), "متن خالی یا حساس در مرحله ${i + 1} رد شد.")
                    }
                    else -> if (argument.isNotBlank()) return TaskPlan(request, emptyList(), "این عملیات نباید آرگومان داشته باشد.")
                }
                steps += TaskStep(action, argument, description, index = i)
            }
            val suppliedId = root.optString("plan_id").takeIf { it.matches(Regex("[A-Za-z0-9_-]{1,64}")) }
            TaskPlan(request, steps, planId = suppliedId ?: UUID.randomUUID().toString())
        } catch (_: Exception) {
            TaskPlan(request, emptyList(), "پاسخ برنامه‌ریز قابل خواندن نیست؛ هیچ اقدامی اجرا نشد.")
        }
    }
}
