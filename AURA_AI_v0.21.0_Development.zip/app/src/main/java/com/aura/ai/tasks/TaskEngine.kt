package com.aura.ai.tasks

import com.aura.ai.accessibility.AuraAccessibilityService
import java.util.UUID

enum class TaskAction { BACK, SCROLL, CLICK_TEXT, TYPE_TEXT }
enum class TaskRisk { LOW, MODERATE }
data class TaskStep(
    val action: TaskAction,
    val argument: String = "",
    val description: String,
    val index: Int = 0
) {
    val risk: TaskRisk get() = when (action) {
        TaskAction.BACK, TaskAction.SCROLL -> TaskRisk.LOW
        TaskAction.CLICK_TEXT, TaskAction.TYPE_TEXT -> TaskRisk.MODERATE
    }
}
data class TaskPlan(
    val originalRequest: String,
    val steps: List<TaskStep>,
    val blockedReason: String? = null,
    val planId: String = UUID.randomUUID().toString()
)
data class TaskStepResult(val success: Boolean, val message: String)

/** Conservative parser: unknown or sensitive requests are never executed. */
object TaskEngine {
    fun createPlan(request: String): TaskPlan {
        val input = request.trim()
        if (input.isEmpty()) return TaskPlan(input, emptyList(), "درخواست خالی است.")
        TaskRiskPolicy.blockedRequestReason(input)?.let { return TaskPlan(input, emptyList(), it) }
        val steps = mutableListOf<TaskStep>()
        val parts = input.split(Regex("\\s*(?:و سپس|سپس|بعدش|\\n)\\s*"))
        for ((index, partRaw) in parts.withIndex()) {
            val part = partRaw.trim().trimEnd('.', '،')
            when {
                part.contains("بازگشت") || part == "برگرد" -> steps += TaskStep(TaskAction.BACK, description = "بازگشت به صفحه قبلی", index = index)
                part.contains("اسکرول") || part.contains("پایین برو") || part.contains("صفحه را پایین") -> steps += TaskStep(TaskAction.SCROLL, description = "یک مرحله اسکرول به پایین", index = index)
                Regex("^(?:روی|دکمه)\\s*(.+?)\\s*(?:را)?\\s*(?:بزن|لمس کن)$").matches(part) -> {
                    val label = Regex("^(?:روی|دکمه)\\s*(.+?)\\s*(?:را)?\\s*(?:بزن|لمس کن)$").matchEntire(part)!!.groupValues[1].trim()
                    val blocked = TaskRiskPolicy.blockedClickReason(label)
                    if (blocked != null) return TaskPlan(input, emptyList(), blocked)
                    steps += TaskStep(TaskAction.CLICK_TEXT, label, "لمس عنصر قابل مشاهده «$label»", index)
                }
                part.startsWith("وارد کن ") || part.startsWith("بنویس ") -> {
                    val value = part.substringAfter(' ').trim().trim('"', '«', '»')
                    if (value.isBlank()) return TaskPlan(input, emptyList(), "متن برای واردکردن خالی است.")
                    if (value.length > 500) return TaskPlan(input, emptyList(), "متن ورودی بیش از ۵۰۰ نویسه است.")
                    if (TaskRiskPolicy.isSensitiveText(value)) return TaskPlan(input, emptyList(), "واردکردن رمز، کد تأیید یا اطلاعات بانکی از طریق این برنامه مجاز نیست.")
                    steps += TaskStep(TaskAction.TYPE_TEXT, value, "واردکردن متن در فیلد فعال", index)
                }
                else -> return TaskPlan(input, emptyList(), "این عبارت به فرمان پشتیبانی‌شده و دقیق تبدیل نشد: «$part». فعلاً فقط بازگشت، اسکرول، لمس دکمه غیرحساس با نام دقیق و واردکردن متن عادی پشتیبانی می‌شود.")
            }
        }
        if (steps.isEmpty()) return TaskPlan(input, emptyList(), "هیچ مرحله قابل اجرایی شناسایی نشد.")
        if (steps.size > 5) return TaskPlan(input, emptyList(), "برای ایمنی هر برنامه حداکثر ۵ مرحله دارد.")
        return TaskPlan(input, steps)
    }

    fun executeStepWithResult(step: TaskStep): TaskStepResult {
        val service = AuraAccessibilityService.active ?: return TaskStepResult(false, "سرویس دسترس‌پذیری فعال نیست.")
        val success = when (step.action) {
            TaskAction.BACK -> service.performBack()
            TaskAction.SCROLL -> service.scrollForward()
            TaskAction.CLICK_TEXT -> if (TaskRiskPolicy.blockedClickReason(step.argument) == null) service.clickVisibleText(step.argument) else false
            TaskAction.TYPE_TEXT -> if (!TaskRiskPolicy.isSensitiveText(step.argument)) service.setTextOnFocusedField(step.argument) else false
        }
        return TaskStepResult(success, if (success) "عملیات انجام شد." else "عنصر پیدا نشد، قابل دسترسی نبود یا عملیات توسط محافظت محلی رد شد.")
    }

    fun executeStep(step: TaskStep): Boolean = executeStepWithResult(step).success
}
