package com.aura.ai

import android.Manifest
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.content.pm.ServiceInfo
import java.io.File
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Brush
import androidx.lifecycle.lifecycleScope
import com.aura.ai.ai.AiClient
import com.aura.ai.ai.ModelCatalog
import com.aura.ai.data.ConversationStore
import com.aura.ai.tasks.AiTaskPlanner
import com.aura.ai.bubble.BubbleService
import com.aura.ai.security.KeyVault
import com.aura.ai.speech.SpeechController
import com.aura.ai.screen.ScreenCaptureService
import com.aura.ai.diagnostics.DeviceCapabilityReport
import com.aura.ai.tasks.TaskEngine
import com.aura.ai.tasks.TaskPlan
import com.aura.ai.tasks.TaskStep
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val capturePathState = mutableStateOf<String?>(null)
    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            capturePathState.value = intent?.getStringExtra(ScreenCaptureService.EXTRA_PATH)
            if (capturePathState.value == null) {
                captureErrorState.value = intent?.getStringExtra(ScreenCaptureService.EXTRA_ERROR) ?: "گرفتن تصویر انجام نشد."
            } else captureErrorState.value = "تصویر صفحه فقط در حافظه موقت برنامه ذخیره شد."
        }
    }
    private val captureErrorState = mutableStateOf("")
    private lateinit var vault: KeyVault
    private lateinit var speech: SpeechController
    private lateinit var conversationStore: ConversationStore
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ScreenCaptureService.ACTION_CAPTURE_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(captureReceiver, filter)
        }
    }
    override fun onStop() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) { }
        super.onStop()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        vault = KeyVault(this); speech = SpeechController(this); conversationStore = ConversationStore(this)
        setContent { AuraApp() }
    }

    override fun onDestroy() {
        speech.shutdown()
        super.onDestroy()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable private fun AuraApp() {
        var provider by remember { mutableStateOf("OpenAI") }
        var apiKey by remember { mutableStateOf(vault.get("OpenAI")) }
        var modelId by remember { mutableStateOf(ModelCatalog.get(this@MainActivity, "OpenAI")) }
        var prompt by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var showSettings by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("آماده‌ام. برای شروع، کلید API مدل را وارد کن.") }
        var taskRequest by remember { mutableStateOf("") }
        var taskPlan by remember { mutableStateOf<TaskPlan?>(null) }
        var taskRunning by remember { mutableStateOf(false) }
        var taskJob by remember { mutableStateOf<Job?>(null) }
        var taskIndex by remember { mutableIntStateOf(0) }
        var taskStatus by remember { mutableStateOf("برای ساخت برنامه، یک دستور روشن بنویس.") }
        var uiInspection by remember { mutableStateOf("") }
        var deviceDiagnostics by remember { mutableStateOf("") }
        var historySearch by remember { mutableStateOf("") }
        var historyMatches by remember { mutableStateOf(emptyList<Pair<String, String>>()) }
        val sessions = remember { mutableStateListOf<ConversationStore.SessionSummary>().apply { addAll(conversationStore.listSessions()) } }
        val messages = remember { mutableStateListOf<Pair<String,String>>().apply { addAll(conversationStore.load()) } }
        LaunchedEffect(messages.size) { conversationStore.save(messages.toList()) }
        val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) prompt = text
        }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        val screenCaptureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this@MainActivity, ScreenCaptureService::class.java)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                status = "در حال گرفتن یک تصویر از صفحه؛ این کار با مجوز همین لحظه تو انجام می‌شود."
            } else status = "اجازه مشاهده صفحه داده نشد؛ هیچ تصویری گرفته نشد."
        }
        MaterialTheme(colorScheme = darkColorScheme(primary = AuraPalette.violet, secondary = AuraPalette.gold, background = AuraPalette.background, surface = AuraPalette.panel, onSurface = Color.White)) {
            Scaffold(containerColor = AuraPalette.background, topBar = {
                TopAppBar(
                    title = { Column { Text("AURA AI", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold, letterSpacing = 2.sp); Text("BEYOND INTELLIGENCE", color = AuraPalette.gold, style = MaterialTheme.typography.labelSmall) } },
                    actions = { TextButton(onClick = { showSettings = !showSettings; if (showSettings) { sessions.clear(); sessions.addAll(conversationStore.listSessions()) } }) { Text(if(showSettings) "گفت‌وگو" else "تنظیمات", color = AuraPalette.gold) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AuraPalette.background)
                )
            }) { padding ->
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101025), AuraPalette.background, Color(0xFF100B19)))).padding(padding).padding(14.dp).then(if (showSettings) Modifier.verticalScroll(rememberScrollState()) else Modifier), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (showSettings) {
                        Text("اتصال مدل هوش مصنوعی", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("OpenAI","Gemini","Claude").forEach { name -> FilterChip(selected = provider == name, onClick = { provider = name; apiKey = vault.get(name); modelId = ModelCatalog.get(this@MainActivity, name) }, label = { Text(name) }) } }
                        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("کلید API برای $provider") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(value = modelId, onValueChange = { modelId = it }, label = { Text("شناسه مدل $provider") }, supportingText = { Text("شناسه مدل را مطابق مستندات ارائه‌دهنده وارد کن.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = { try { vault.put(provider, apiKey); ModelCatalog.save(this@MainActivity, provider, modelId); status = "کلید و شناسه مدل $provider ذخیره شدند." } catch (e: Exception) { status = e.message ?: "ذخیره تنظیمات ناموفق بود." } }) { Text("ذخیره تنظیمات مدل") }
                        Divider()
                        Text("حباب شناور", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { if (Settings.canDrawOverlays(this@MainActivity)) startBubble() else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }) { Text("فعال‌سازی حباب شناور") }
                        Text("کنترل صفحه با Accessibility", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("بازکردن تنظیمات دسترس‌پذیری") }
                        Text("این مجوز را فقط در صورت تمایل و آگاهی فعال کن.", color = Color.LightGray)
                        Divider()
                        Text("وضعیت و بررسی صفحه", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        OutlinedButton(onClick = { deviceDiagnostics = DeviceCapabilityReport.create(this@MainActivity) }) { Text("گزارش سلامت و سازگاری گوشی") }
                        if (deviceDiagnostics.isNotBlank()) Text(deviceDiagnostics, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Text("گفتار فارسی: ${if (speech.supportsPersian()) "آماده" else "در حال آماده‌سازی یا پشتیبانی‌نشده توسط موتور گفتار گوشی"}", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Text("حباب شناور: ${if (Settings.canDrawOverlays(this@MainActivity)) "مجاز" else "غیرفعال"}  |  دسترس‌پذیری: ${if (com.aura.ai.accessibility.AuraAccessibilityService.active != null) "فعال" else "غیرفعال"}", color = Color.LightGray)
                        OutlinedButton(onClick = {
                            val service = com.aura.ai.accessibility.AuraAccessibilityService.active
                            uiInspection = if (service == null) "برای بررسی ساختار صفحه، ابتدا سرویس دسترس‌پذیری را فعال کن." else {
                                val snapshot = service.inspectActiveWindow()
                                "برنامه: ${snapshot.packageName}\nعناصر تعاملی: ${snapshot.elements.size}\n" + snapshot.elements.take(35).joinToString("\n") { "• ${it.label} | ${if (it.clickable) "قابل لمس" else "قابل ویرایش"} | ${if (it.enabled) "فعال" else "غیرفعال"}" }
                            }
                        }) { Text("بررسی عناصر صفحه فعلی") }
                        if (uiInspection.isNotBlank()) Text(uiInspection, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Divider()
                        Text("مدیریت گفت‌وگوها", color = Color.White, style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(value = historySearch, onValueChange = { historySearch = it }, label = { Text("جست‌وجو در پیام‌های ذخیره‌شده") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedButton(onClick = { historyMatches = conversationStore.searchMessages(historySearch) }) { Text("جست‌وجو") }
                        historyMatches.take(8).forEach { (role, body) -> Text("${if (role == "user") "تو" else "AURA"}: ${body.take(180)}", color = Color.LightGray, style = MaterialTheme.typography.bodySmall) }
                        Text("جلسه‌های ذخیره‌شده", color = Color.White, style = MaterialTheme.typography.titleSmall)
                        sessions.take(8).forEach { session ->
                            TextButton(onClick = {
                                if (conversationStore.switchSession(session.id)) {
                                    messages.clear(); messages.addAll(conversationStore.load()); conversationStore.save(messages.toList()); status = "گفت‌وگو بارگذاری شد: ${session.title}"
                                }
                            }) { Text("${session.title} (${session.messageCount})") }
                        }
                    } else {
                        AuraHeroCard(provider = provider, busy = busy, onVoice = { if (Build.VERSION.SDK_INT >= 23) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO); speechLauncher.launch(speech.recognitionIntent()) }, onSettings = { showSettings = true })
                        AuraSectionLabel("ابزارهای هوشمند", "NEXUS CONTROL")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                capturePathState.value = null
                                captureErrorState.value = "منتظر اجازه سیستم برای مشاهده صفحه هستم."
                                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
                            }) { Text("مشاهده صفحه") }
                            if (capturePathState.value != null) {
                                OutlinedButton(onClick = { File(capturePathState.value!!).delete(); capturePathState.value = null; captureErrorState.value = "تصویر موقت حذف شد." }) { Text("حذف تصویر") }
                                Button(enabled = !busy, onClick = {
                                    val file = File(capturePathState.value!!)
                                    messages.add("user" to "تصویر صفحه را تحلیل کن.")
                                    busy = true; status = "تصویر صفحه در حال ارسال به $provider برای تحلیل است."
                                    lifecycleScope.launch {
                                        try {
                                            val answer = withContext(Dispatchers.IO) {
                                                AiClient().analyzeImage(provider, vault.get(provider), "این تصویر از صفحه گوشی من است. محتوای قابل مشاهده را به فارسی توضیح بده، عناصر مهم را شناسایی کن و اگر پرسشی لازم است پاسخ بده. از حدس‌زدن اطلاعات پنهان خودداری کن.", file, modelId)
                                            }
                                            messages.add("assistant" to answer); status = "تحلیل تصویر تمام شد."
                                        } catch (e: Exception) { status = e.message ?: "خطای تحلیل تصویر"; messages.add("assistant" to status) }
                                        finally { busy = false; capturePathState.value = null; file.delete() }
                                    }
                                }) { Text("تحلیل تصویر") }
                            }
                        }
                        if (captureErrorState.value.isNotBlank()) Text(captureErrorState.value, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        // Task planner: plan preview is separate from execution; no action runs before explicit approval.
                        Surface(color = AuraPalette.panelAlt, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("برنامه‌ریز و اجرای وظایف", color = AuraPalette.electricBlue, style = MaterialTheme.typography.titleSmall)
                                OutlinedTextField(value = taskRequest, onValueChange = { taskRequest = it; taskPlan = null }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("مثلاً: پایین برو و سپس بازگشت") }, maxLines = 2)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(enabled = !taskRunning && taskRequest.isNotBlank(), onClick = {
                                        taskPlan = TaskEngine.createPlan(taskRequest)
                                        taskIndex = 0
                                        taskStatus = if (taskPlan?.blockedReason == null) "برنامه محلی آماده بررسی است؛ هنوز هیچ کاری اجرا نشده." else taskPlan!!.blockedReason!!
                                    }) { Text("برنامه ساده") }
                                    OutlinedButton(enabled = !taskRunning && !busy && taskRequest.isNotBlank(), onClick = {
                                        val requestText = taskRequest.trim()
                                        busy = true; taskPlan = null; taskStatus = "هوش مصنوعی در حال پیشنهاد مراحل است؛ هنوز هیچ کاری اجرا نمی‌شود."
                                        lifecycleScope.launch {
                                            try {
                                                val raw = withContext(Dispatchers.IO) { AiClient().planTask(provider, vault.get(provider), requestText, modelId) }
                                                taskPlan = AiTaskPlanner.parse(requestText, raw)
                                                taskStatus = if (taskPlan?.blockedReason == null) "پیشنهاد AI آماده بازبینی است؛ برای اجرا تأیید جداگانه لازم است." else taskPlan!!.blockedReason!!
                                            } catch (e: Exception) { taskStatus = e.message ?: "برنامه‌ریزی AI ناموفق بود." }
                                            finally { busy = false }
                                        }
                                    }) { Text("برنامه‌ریزی با AI") }
                                    if (taskRunning) OutlinedButton(onClick = {
                                        taskJob?.cancel()
                                        taskRunning = false
                                        taskStatus = "درخواست توقف ثبت شد؛ مرحله جاری دیگر ادامه نمی‌یابد."
                                    }) { Text("توقف فوری") }
                                }
                                taskPlan?.let { plan ->
                                    if (plan.blockedReason != null) Text(plan.blockedReason, color = Color(0xFFFFB4AB))
                                    else {
                                        Text("شناسه برنامه: ${plan.planId.take(12)}", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                        plan.steps.forEachIndexed { index, step ->
                                            Text("${index + 1}. ${step.description} | ریسک: ${if (step.risk == com.aura.ai.tasks.TaskRisk.LOW) "کم" else "متوسط"}", color = Color.White, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text("تمام مراحل پیش از اجرا نمایش داده می‌شوند؛ عملیات حساس همچنان مسدود است و اجرای برنامه نیازمند تأیید صریح توست.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                        Button(enabled = !taskRunning && plan.steps.isNotEmpty(), onClick = {
                                            if (com.aura.ai.accessibility.AuraAccessibilityService.active == null) {
                                                taskStatus = "ابتدا سرویس AURA Accessibility را در تنظیمات اندروید فعال کن."
                                            } else {
                                                taskRunning = true; taskIndex = 0; taskStatus = "اجرای برنامه با تأیید تو آغاز شد."
                                                taskJob = lifecycleScope.launch {
                                                    var completed = true
                                                    try {
                                                        for ((index, step) in plan.steps.withIndex()) {
                                                            coroutineContext.ensureActive()
                                                            if (com.aura.ai.accessibility.AuraAccessibilityService.active == null) {
                                                                taskStatus = "سرویس دسترس‌پذیری قطع شد؛ اجرا متوقف شد."
                                                                completed = false
                                                                break
                                                            }
                                                            taskIndex = index
                                                            val stepResult = withContext(Dispatchers.Main) { TaskEngine.executeStepWithResult(step) }
                                                            if (!stepResult.success) {
                                                                taskStatus = "مرحله ${index + 1} انجام نشد: ${stepResult.message} اجرا متوقف شد."
                                                                completed = false
                                                                break
                                                            }
                                                            taskStatus = "مرحله ${index + 1} از ${plan.steps.size} انجام شد."
                                                            kotlinx.coroutines.delay(650)
                                                        }
                                                        if (completed) taskStatus = "تمام مراحل برنامه اجرا شدند."
                                                    } catch (cancelled: kotlinx.coroutines.CancellationException) {
                                                        taskStatus = "اجرای وظیفه لغو شد."
                                                        throw cancelled
                                                    } finally {
                                                        taskRunning = false
                                                        taskJob = null
                                                    }
                                                }
                                            }
                                        }) { Text("تأیید و اجرای برنامه") }
                                    }
                                }
                                Text(taskStatus, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (messages.isEmpty()) item { Text("AURA آماده است. پرسشت را بنویس یا با میکروفون بگو.", color = Color.LightGray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(22.dp)) }
                            items(messages) { (role, body) -> Surface(color = if(role == "user") Color(0xFF29204B) else Color(0xFF171A2B), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Text((if(role=="user") "تو: " else "AURA: ") + body, color = Color.White, modifier = Modifier.padding(12.dp)) } }
                        }
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(status, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.weight(1f), placeholder = { Text("پیامت را بنویس...") }, maxLines = 4)
                            IconButton(onClick = { if (Build.VERSION.SDK_INT >= 23) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO); speechLauncher.launch(speech.recognitionIntent()) }) { Icon(Icons.Default.Mic, "گفتار", tint = AuraPalette.electricBlue) }
                            IconButton(enabled = !busy && prompt.isNotBlank(), onClick = {
                                val question = prompt.trim(); prompt = ""; messages.add("user" to question); busy = true; status = "در حال دریافت پاسخ از $provider..."
                                lifecycleScope.launch {
                                    try {
                                        val history = messages.dropLast(1).takeLast(12)
                                        val answer = withContext(Dispatchers.IO) { AiClient().ask(provider, vault.get(provider), question, history, modelId) }
                                        messages.add("assistant" to answer); status = "پاسخ دریافت شد."
                                    } catch (e: Exception) { status = e.message ?: "خطای ناشناخته"; messages.add("assistant" to "در اتصال مشکلی رخ داد: $status") }
                                    finally { busy = false }
                                }
                            }) { Icon(Icons.Default.Send, "ارسال", tint = AuraPalette.electricBlue) }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { conversationStore.newSession(); messages.clear(); sessions.clear(); sessions.addAll(conversationStore.listSessions()); status = "گفت‌وگوی تازه ساخته شد." }) { Text("گفت‌وگوی تازه") }
                            OutlinedButton(onClick = { messages.clear(); conversationStore.clear(); sessions.clear(); sessions.addAll(conversationStore.listSessions()); status = "گفت‌وگوی جاری پاک شد." }) { Text("پاک‌کردن") }
                            OutlinedButton(enabled = messages.any { it.first == "assistant" }, onClick = {
                                val latest = messages.lastOrNull { it.first == "assistant" }?.second.orEmpty()
                                status = if (speech.speak(latest)) "پخش پاسخ فارسی آغاز شد." else "موتور گفتار فارسی گوشی آماده یا در دسترس نیست."
                            }) { Text("خواندن پاسخ") }
                            OutlinedButton(onClick = { speech.stop(); status = "پخش صدا متوقف شد." }) { Text("توقف صدا") }
                        }
                    }
                }
            }
        }
    }
    private fun startBubble() { if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, BubbleService::class.java)) else startService(Intent(this, BubbleService::class.java)) }
}
