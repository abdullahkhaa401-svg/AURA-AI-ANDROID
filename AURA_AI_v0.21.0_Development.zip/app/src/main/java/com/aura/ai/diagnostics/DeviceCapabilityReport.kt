package com.aura.ai.diagnostics

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.aura.ai.accessibility.AuraAccessibilityService

/** Read-only local diagnostics. No screen contents, keys, or conversation text are collected. */
object DeviceCapabilityReport {
    fun create(context: Context): String {
        val overlay = Settings.canDrawOverlays(context)
        val accessibility = AuraAccessibilityService.active != null
        val memory = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val info = android.app.ActivityManager.MemoryInfo().also { memory.getMemoryInfo(it) }
        val freeRamMb = info.availMem / (1024L * 1024L)
        val totalRamMb = info.totalMem / (1024L * 1024L)
        val cacheMb = (context.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }) / (1024L * 1024L)
        return buildString {
            appendLine("گزارش محلی AURA")
            appendLine("اندروید: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("حباب شناور: ${if (overlay) "مجاز" else "نیازمند اجازه"}")
            appendLine("دسترس‌پذیری: ${if (accessibility) "فعال" else "غیرفعال"}")
            appendLine("حافظه RAM آزاد: ${freeRamMb}MB از ${totalRamMb}MB")
            appendLine("فضای cache برنامه: ${cacheMb}MB")
            appendLine("این گزارش فقط وضعیت فنی محلی را نشان می‌دهد و چیزی به سرور ارسال نمی‌کند.")
        }
    }
}
