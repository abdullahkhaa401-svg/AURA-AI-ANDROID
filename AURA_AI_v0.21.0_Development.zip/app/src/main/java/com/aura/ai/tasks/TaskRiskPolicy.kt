package com.aura.ai.tasks

/**
 * Conservative local guardrails. This is intentionally deny-by-default for
 * sensitive UI actions; it is not a substitute for Android's own protections.
 */
object TaskRiskPolicy {
    private val sensitiveRequestTerms = listOf(
        "پرداخت", "انتقال پول", "انتقال وجه", "خرید", "سفارش", "حذف", "پاک کردن",
        "ارسال پیام", "ارسال ایمیل", "ارسال پست", "انتشار", "رمز عبور", "پسورد",
        "کد تأیید", "کد تایید", "رمز یکبارمصرف", "برداشت", "واریز", "ثبت نهایی",
        "تأیید نهایی", "تایید نهایی", "خریداری", "اشتراک بخر",
        "تماس بگیر", "تماس تلفنی", "تماس صوتی", "اشتراک‌گذاری", "share", "call",
        "grant permission", "اجازه دسترسی", "فعال‌سازی دسترسی", "مجوز دسترسی"
    )

    private val sensitiveClickLabels = listOf(
        "پرداخت", "pay", "purchase", "buy", "checkout", "حذف", "delete", "remove",
        "ارسال", "send", "submit", "تأیید", "تایید", "confirm", "transfer", "انتقال",
        "واریز", "برداشت", "publish", "انتشار", "سفارش", "order",
        "تماس", "call", "share", "اشتراک", "مجوز", "اجازه دسترسی", "grant"
    )

    fun blockedRequestReason(request: String): String? {
        val term = sensitiveRequestTerms.firstOrNull { request.contains(it, ignoreCase = true) }
        return term?.let { "این درخواست شامل عملیات حساس «$it» است و در این نسخه اجرا نمی‌شود." }
    }

    fun blockedClickReason(label: String): String? {
        val normalized = label.trim()
        val term = sensitiveClickLabels.firstOrNull { normalized.contains(it, ignoreCase = true) }
        return term?.let { "لمس دکمه‌ای با عنوان حساس «$it» در این نسخه مجاز نیست." }
    }

    fun isSensitiveText(value: String): Boolean {
        val terms = listOf("رمز", "پسورد", "password", "کد تایید", "کد تأیید", "otp", "cvv", "کارت بانکی", "شماره کارت", "شبا", "cvv2", "security code")
        return terms.any { value.contains(it, ignoreCase = true) }
    }
}
