package com.aura.ai.screen

/** Bounds screenshot dimensions to limit transient bitmap memory use. */
object CaptureSizing {
    data class Size(val width: Int, val height: Int)
    fun fit(width: Int, height: Int, maxDimension: Int = 1440): Size {
        require(maxDimension > 0)
        val safeWidth = width.coerceAtLeast(1)
        val safeHeight = height.coerceAtLeast(1)
        val scale = minOf(1.0, maxDimension.toDouble() / maxOf(safeWidth, safeHeight))
        return Size((safeWidth * scale).toInt().coerceAtLeast(1), (safeHeight * scale).toInt().coerceAtLeast(1))
    }
}
