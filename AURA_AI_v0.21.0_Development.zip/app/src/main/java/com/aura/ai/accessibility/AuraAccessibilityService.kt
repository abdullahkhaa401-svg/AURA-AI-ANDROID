package com.aura.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.text.InputType
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import com.aura.ai.tasks.TaskRiskPolicy

data class UiElementInfo(val label: String, val className: String, val clickable: Boolean, val editable: Boolean, val enabled: Boolean)
data class UiSnapshot(val packageName: String, val capturedAtElapsedMs: Long, val visibleText: String, val elements: List<UiElementInfo>)

/** UI actions are limited to visible, enabled controls after user approval. */
class AuraAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    fun visibleText(): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null || out.length > 12000 || !node.isVisibleToUser) return
            val text = node.text?.toString()?.takeIf { it.isNotBlank() }
            val desc = node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            if (text != null) out.append(text).append('\n') else if (desc != null) out.append(desc).append('\n')
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return out.toString()
    }

    /** Returns a bounded structural summary; callers decide explicitly whether to share it with an AI provider. */
    fun inspectActiveWindow(): UiSnapshot {
        val root = rootInActiveWindow ?: return UiSnapshot("", SystemClock.elapsedRealtime(), "", emptyList())
        val text = StringBuilder()
        val elements = mutableListOf<UiElementInfo>()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null || !node.isVisibleToUser || elements.size >= 120 || text.length >= 12000) return
            val label = (node.text?.toString() ?: node.contentDescription?.toString()).orEmpty().trim()
            if (label.isNotBlank()) {
                if (text.length < 12000) text.append(label.take(300)).append('\n')
                if (node.isClickable || node.isEditable) elements += UiElementInfo(
                    label.take(120), node.className?.toString().orEmpty().take(100),
                    node.isClickable, node.isEditable, node.isEnabled
                )
            }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return UiSnapshot(root.packageName?.toString().orEmpty(), SystemClock.elapsedRealtime(), text.toString(), elements.distinctBy { it.label to it.className })
    }

    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null || !node.isVisibleToUser) return null
            if (node.isScrollable && node.isEnabled) return node
            for (i in 0 until node.childCount) findScrollable(node.getChild(i))?.let { return it }
            return null
        }
        val target = findScrollable(root) ?: return false
        return target.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun clickVisibleText(label: String): Boolean {
        if (label.isBlank() || TaskRiskPolicy.blockedClickReason(label) != null) return false
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(label)
        val exactTargets = matches.filter { match ->
            if (!match.isVisibleToUser || !match.isEnabled) return@filter false
            val exact = match.text?.toString()?.trim()?.equals(label.trim(), ignoreCase = true) == true ||
                match.contentDescription?.toString()?.trim()?.equals(label.trim(), ignoreCase = true) == true
            if (!exact) return@filter false
            var node: AccessibilityNodeInfo? = match
            var clickable = false
            var depth = 0
            while (node != null && node.isVisibleToUser && depth < 8) {
                if (node.isClickable && node.isEnabled) { clickable = true; break }
                node = node.parent
                depth++
            }
            clickable
        }
        // Refuse ambiguous labels rather than tapping an arbitrary matching control.
        if (exactTargets.size != 1) return false
        var node: AccessibilityNodeInfo? = exactTargets.single()
        var depth = 0
        while (node != null && node.isVisibleToUser && depth < 8) {
            if (node.isClickable && node.isEnabled) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            node = node.parent
            depth++
        }
        return false
    }

    fun setTextOnFocusedField(value: String): Boolean {
        if (value.isBlank() || TaskRiskPolicy.isSensitiveText(value)) return false
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!focused.isVisibleToUser || !focused.isEditable || !focused.isEnabled || focused.isPassword) return false
        val variation = focused.inputType and InputType.TYPE_MASK_VARIATION
        val passwordInput = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
        if (passwordInput) return false
        val hint = focused.hintText?.toString().orEmpty()
        val description = focused.contentDescription?.toString().orEmpty()
        if (TaskRiskPolicy.isSensitiveText(hint) || TaskRiskPolicy.isSensitiveText(description)) return false
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,
            android.os.Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value) })
    }

    companion object { @Volatile var active: AuraAccessibilityService? = null }
}
