package com.aura.ai.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.io.File
import java.util.Base64

class AiClient {
    private val http = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()
    fun planTask(provider: String, apiKey: String, requestText: String, modelId: String = ModelCatalog.defaultFor(provider)): String {
        val instruction = """You are AURA's constrained Android UI planner. Return ONLY JSON, no markdown.
Allowed schema: {"needs_clarification":false,"clarification":"","steps":[{"action":"BACK|SCROLL|CLICK_TEXT|TYPE_TEXT","argument":"","description":""}]}
Rules: maximum 5 steps; only use these four actions; never propose payments, purchases, money transfer, deletion, sending, publishing, submitting, confirmations, passwords, OTP, credentials, or banking actions. CLICK_TEXT argument must be an exact visible non-sensitive label. TYPE_TEXT may contain only ordinary non-sensitive text. BACK and SCROLL arguments must be empty. If uncertain or clarification is needed, return needs_clarification=true, a concise Persian clarification, and an empty steps array. Do not claim execution. User request: $requestText"""
        return ask(provider, apiKey, instruction, emptyList(), modelId)
    }

    fun ask(provider: String, apiKey: String, prompt: String, history: List<Pair<String, String>>, modelId: String = ModelCatalog.defaultFor(provider)): String {
        require(provider in listOf("OpenAI", "Gemini", "Claude")) { "ارائه‌دهنده ناشناخته است." }
        require(ModelCatalog.isValidModelId(modelId)) { "شناسه مدل نامعتبر است." }
        require(apiKey.isNotBlank()) { "ابتدا کلید API این مدل را در تنظیمات وارد کن." }
        val json = when (provider) {
            "OpenAI" -> openAi(prompt, history, modelId)
            "Gemini" -> gemini(prompt, history, modelId)
            else -> claude(prompt, history, modelId)
        }
        val request = when (provider) {
            "OpenAI" -> Request.Builder().url("https://api.openai.com/v1/chat/completions").header("Authorization", "Bearer $apiKey").post(json.toString().toRequestBody("application/json".toMediaType())).build()
            "Gemini" -> Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=$apiKey").post(json.toString().toRequestBody("application/json".toMediaType())).build()
            else -> Request.Builder().url("https://api.anthropic.com/v1/messages").header("x-api-key", apiKey).header("anthropic-version", "2023-06-01").post(json.toString().toRequestBody("application/json".toMediaType())).build()
        }
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("خطای سرویس $provider (${response.code}): ${body.take(500)}")
            val data = JSONObject(body)
            return when (provider) {
                "OpenAI" -> data.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                "Gemini" -> data.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                else -> data.getJSONArray("content").getJSONObject(0).getString("text")
            }
        }
    }

    fun analyzeImage(provider: String, apiKey: String, prompt: String, imageFile: File, modelId: String = ModelCatalog.defaultFor(provider)): String {
        require(provider in listOf("OpenAI", "Gemini", "Claude")) { "ارائه‌دهنده ناشناخته است." }
        require(ModelCatalog.isValidModelId(modelId)) { "شناسه مدل نامعتبر است." }
        require(apiKey.isNotBlank()) { "ابتدا کلید API این مدل را در تنظیمات وارد کن." }
        require(imageFile.exists() && imageFile.length() > 0L) { "تصویر صفحه پیدا نشد؛ دوباره تصویر بگیر." }
        val encoded = Base64.getEncoder().encodeToString(imageFile.readBytes())
        val json = when (provider) {
            "OpenAI" -> JSONObject().put("model", modelId).put("messages", JSONArray().put(
                JSONObject().put("role", "user").put("content", JSONArray()
                    .put(JSONObject().put("type", "text").put("text", prompt))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$encoded"))))
            ))
            "Gemini" -> JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", encoded))))))
            else -> JSONObject().put("model", modelId).put("max_tokens", 2048).put("messages", JSONArray().put(
                JSONObject().put("role", "user").put("content", JSONArray()
                    .put(JSONObject().put("type", "text").put("text", prompt))
                    .put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", encoded))))
            ))
        }
        val request = when (provider) {
            "OpenAI" -> Request.Builder().url("https://api.openai.com/v1/chat/completions").header("Authorization", "Bearer $apiKey").post(json.toString().toRequestBody("application/json".toMediaType())).build()
            "Gemini" -> Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=$apiKey").post(json.toString().toRequestBody("application/json".toMediaType())).build()
            else -> Request.Builder().url("https://api.anthropic.com/v1/messages").header("x-api-key", apiKey).header("anthropic-version", "2023-06-01").post(json.toString().toRequestBody("application/json".toMediaType())).build()
        }
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("خطای تحلیل تصویر $provider (${response.code}): ${body.take(350)}")
            val data = JSONObject(body)
            return when (provider) {
                "OpenAI" -> data.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                "Gemini" -> data.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                else -> data.getJSONArray("content").getJSONObject(0).getString("text")
            }
        }
    }

    private fun openAi(prompt: String, history: List<Pair<String,String>>, modelId: String) = JSONObject().put("model", modelId).put("messages", JSONArray().apply { put(JSONObject().put("role","system").put("content","You are AURA AI, a careful Android assistant. Reply in the user's language. Never claim an action was performed unless it was.")); history.takeLast(12).forEach { put(JSONObject().put("role",it.first).put("content",it.second)) }; put(JSONObject().put("role","user").put("content",prompt)) })
    private fun gemini(prompt: String, history: List<Pair<String,String>>, modelId: String) = JSONObject().put("contents", JSONArray().apply { history.takeLast(12).forEach { (role, text) -> put(JSONObject().put("role",if(role=="assistant") "model" else "user").put("parts",JSONArray().put(JSONObject().put("text",text)))) }; put(JSONObject().put("role","user").put("parts",JSONArray().put(JSONObject().put("text",prompt)))) })
    private fun claude(prompt: String, history: List<Pair<String,String>>, modelId: String) = JSONObject().put("model",modelId).put("max_tokens",2048).put("messages",JSONArray().apply { history.takeLast(12).forEach { (role,text) -> put(JSONObject().put("role",role).put("content",text)) }; put(JSONObject().put("role","user").put("content",prompt)) })
}
