package com.aura.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** On-device, bounded multi-session history. No conversation is uploaded by this class. */
class ConversationStore(context: Context) {
    private val prefs = context.getSharedPreferences("aura_conversation_v2", Context.MODE_PRIVATE)
    private val legacyPrefs = context.getSharedPreferences("aura_conversation_v1", Context.MODE_PRIVATE)
    private var currentSessionId: String = prefs.getString(KEY_CURRENT, null) ?: migrateLegacyIfNeeded()

    data class SessionSummary(val id: String, val title: String, val messageCount: Int, val updatedAt: Long)

    @Synchronized fun load(): List<Pair<String, String>> = readSessions()[currentSessionId]?.messages.orEmpty().takeLast(MAX_MESSAGES)

    @Synchronized fun save(messages: List<Pair<String, String>>) {
        val sessions = readSessions().toMutableMap()
        val old = sessions[currentSessionId]
        val valid = messages.takeLast(MAX_MESSAGES).mapNotNull { (role, body) ->
            if ((role == "user" || role == "assistant") && body.isNotBlank()) role to body.take(MAX_BODY_CHARS) else null
        }
        sessions[currentSessionId] = SessionData(old?.createdAt ?: System.currentTimeMillis(), System.currentTimeMillis(), valid)
        writeSessions(sessions)
    }

    @Synchronized fun clear() {
        val sessions = readSessions().toMutableMap()
        sessions.remove(currentSessionId)
        currentSessionId = UUID.randomUUID().toString()
        sessions[currentSessionId] = SessionData(System.currentTimeMillis(), System.currentTimeMillis(), emptyList())
        writeSessions(sessions)
    }

    @Synchronized fun newSession(): String {
        currentSessionId = UUID.randomUUID().toString()
        val sessions = readSessions().toMutableMap()
        sessions[currentSessionId] = SessionData(System.currentTimeMillis(), System.currentTimeMillis(), emptyList())
        writeSessions(sessions)
        return currentSessionId
    }

    @Synchronized fun switchSession(id: String): Boolean {
        if (id !in readSessions()) return false
        currentSessionId = id
        prefs.edit().putString(KEY_CURRENT, id).apply()
        return true
    }

    @Synchronized fun listSessions(): List<SessionSummary> = readSessions().map { (id, data) ->
        SessionSummary(id, data.messages.firstOrNull { it.first == "user" }?.second?.take(42) ?: "گفت‌وگوی تازه", data.messages.size, data.updatedAt)
    }.sortedByDescending { it.updatedAt }

    @Synchronized fun searchMessages(query: String): List<Pair<String, String>> {
        val q = query.trim()
        if (q.isBlank()) return emptyList()
        return readSessions().values.flatMap { it.messages }.filter { it.second.contains(q, ignoreCase = true) }.takeLast(50)
    }

    private data class SessionData(val createdAt: Long, val updatedAt: Long, val messages: List<Pair<String, String>>)

    private fun migrateLegacyIfNeeded(): String {
        val id = UUID.randomUUID().toString()
        val raw = legacyPrefs.getString("messages", null)
        val migrated = try {
            val array = JSONArray(raw ?: "[]")
            (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                val role = item.optString("role")
                val body = item.optString("body")
                if ((role == "user" || role == "assistant") && body.isNotBlank()) role to body.take(MAX_BODY_CHARS) else null
            }.takeLast(MAX_MESSAGES)
        } catch (_: Exception) { emptyList() }
        val now = System.currentTimeMillis()
        val obj = JSONObject().put(id, sessionToJson(SessionData(now, now, migrated)))
        prefs.edit().putString(KEY_SESSIONS, obj.toString()).putString(KEY_CURRENT, id).apply()
        legacyPrefs.edit().remove("messages").apply()
        return id
    }

    private fun readSessions(): Map<String, SessionData> {
        val raw = prefs.getString(KEY_SESSIONS, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val result = linkedMapOf<String, SessionData>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val obj = root.optJSONObject(id) ?: continue
                val array = obj.optJSONArray("messages") ?: JSONArray()
                val messages = (0 until array.length()).mapNotNull { i ->
                    val item = array.optJSONObject(i) ?: return@mapNotNull null
                    val role = item.optString("role")
                    val body = item.optString("body")
                    if ((role == "user" || role == "assistant") && body.isNotBlank()) role to body.take(MAX_BODY_CHARS) else null
                }.takeLast(MAX_MESSAGES)
                result[id] = SessionData(obj.optLong("createdAt"), obj.optLong("updatedAt"), messages)
            }
            result
        } catch (_: Exception) { emptyMap() }
    }

    private fun writeSessions(sessions: Map<String, SessionData>) {
        val limited = sessions.entries.sortedByDescending { it.value.updatedAt }.take(MAX_SESSIONS).associate { it.toPair() }
        val root = JSONObject()
        limited.forEach { (id, data) -> root.put(id, sessionToJson(data)) }
        if (currentSessionId !in limited) currentSessionId = limited.keys.firstOrNull() ?: UUID.randomUUID().toString()
        prefs.edit().putString(KEY_SESSIONS, root.toString()).putString(KEY_CURRENT, currentSessionId).apply()
    }

    private fun sessionToJson(data: SessionData) = JSONObject().put("createdAt", data.createdAt).put("updatedAt", data.updatedAt).put("messages", JSONArray().apply {
        data.messages.takeLast(MAX_MESSAGES).forEach { (role, body) -> put(JSONObject().put("role", role).put("body", body)) }
    })

    companion object {
        private const val KEY_SESSIONS = "sessions"
        private const val KEY_CURRENT = "current_session"
        private const val MAX_SESSIONS = 30
        private const val MAX_MESSAGES = 80
        private const val MAX_BODY_CHARS = 12000
    }
}
