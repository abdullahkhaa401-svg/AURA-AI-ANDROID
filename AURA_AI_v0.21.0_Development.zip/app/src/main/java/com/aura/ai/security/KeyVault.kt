package com.aura.ai.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class KeyVault(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "aura_secure_keys",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun get(provider: String): String = prefs.getString(provider, "") ?: ""
    fun put(provider: String, key: String) { prefs.edit().putString(provider, key.trim()).apply() }
}
