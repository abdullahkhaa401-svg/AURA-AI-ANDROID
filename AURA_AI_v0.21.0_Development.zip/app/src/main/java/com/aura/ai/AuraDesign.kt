package com.aura.ai

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal object AuraPalette {
    val background = Color(0xFF070811)
    val panel = Color(0xE6151728)
    val panelAlt = Color(0xFF111426)
    val violet = Color(0xFF9A4DFF)
    val electricBlue = Color(0xFF28BFFF)
    val gold = Color(0xFFFFC85A)
    val muted = Color(0xFFB7B5C9)
    val success = Color(0xFF45D6A1)
}

@Composable
internal fun AuraHeroCard(provider: String, busy: Boolean, onVoice: () -> Unit, onSettings: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        color = AuraPalette.panel,
        border = androidx.compose.foundation.BorderStroke(1.dp, AuraPalette.violet.copy(alpha = .45f)),
        shadowElevation = 14.dp
    ) {
        Box(
            modifier = Modifier
                .background(Brush.linearGradient(listOf(Color(0xFF17142B), Color(0xFF090D1B), Color(0xFF171020))))
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("AURA AI", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                        Text("BEYOND INTELLIGENCE", color = AuraPalette.gold, fontSize = 9.sp, letterSpacing = 2.sp)
                    }
                    Surface(color = Color(0xFF092A27), shape = CircleShape, border = androidx.compose.foundation.BorderStroke(1.dp, AuraPalette.success.copy(alpha = .55f))) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(AuraPalette.success))
                            Spacer(Modifier.width(6.dp))
                            Text(if (busy) "در حال پردازش" else "آماده به کار", color = AuraPalette.success, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Box(Modifier.size(154.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val c = center
                        drawCircle(Brush.radialGradient(listOf(AuraPalette.violet.copy(alpha = .25f), AuraPalette.electricBlue.copy(alpha = .08f), Color.Transparent), c, size.minDimension * .49f), radius = size.minDimension * .49f)
                        drawCircle(AuraPalette.electricBlue.copy(alpha = .75f), radius = size.minDimension * .39f, style = Stroke(width = 1.4.dp.toPx()))
                        drawCircle(AuraPalette.violet.copy(alpha = .9f), radius = size.minDimension * .32f, style = Stroke(width = 2.dp.toPx()))
                        drawArc(AuraPalette.gold.copy(alpha = .95f), 205f, 125f, false, topLeft = androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .08f), size = androidx.compose.ui.geometry.Size(size.width * .84f, size.height * .84f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
                        drawArc(AuraPalette.electricBlue, 20f, 115f, false, topLeft = androidx.compose.ui.geometry.Offset(size.width * .08f, size.height * .08f), size = androidx.compose.ui.geometry.Size(size.width * .84f, size.height * .84f), style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                    }
                    Surface(shape = CircleShape, color = Color(0xFF100D24), border = androidx.compose.foundation.BorderStroke(2.dp, AuraPalette.violet), shadowElevation = 18.dp) {
                        Box(Modifier.size(76.dp).background(Brush.radialGradient(listOf(Color(0xFF422078), Color(0xFF100D24)))), contentAlignment = Alignment.Center) {
                            Text("A", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
                Text(if (busy) "در حال اندیشیدن..." else "سلام، من AURA هستم", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("چه کاری برایت انجام بدهم؟", color = AuraPalette.muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Button(onClick = onVoice, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = AuraPalette.violet)) {
                        Text("🎙  مکالمه صوتی", fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onSettings, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, AuraPalette.gold.copy(alpha = .7f))) {
                        Text("تنظیمات و مدل‌ها", color = AuraPalette.gold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("مدل فعال: $provider", color = AuraPalette.muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
internal fun AuraSectionLabel(title: String, detail: String = "") {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (detail.isNotBlank()) Text(detail, color = AuraPalette.gold, fontSize = 10.sp)
    }
}
