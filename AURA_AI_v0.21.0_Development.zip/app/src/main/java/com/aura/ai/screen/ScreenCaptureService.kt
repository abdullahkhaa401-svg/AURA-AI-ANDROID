package com.aura.ai.screen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "aura_screen_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, "AURA screen capture", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("AURA AI")
            .setContentText("مشاهده صفحه با اجازه شما فعال است؛ پس از گرفتن تصویر متوقف می‌شود.")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(52, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(52, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                            else intent?.getParcelableExtra(EXTRA_DATA)
        if (resultCode == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            captureOneFrame()
        } catch (e: Exception) {
            sendResult(null, "گرفتن تصویر صفحه ناموفق بود: ${e.message ?: "خطای سیستم"}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun captureOneFrame() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        thread = HandlerThread("AuraScreenCapture").apply { start() }
        val handler = Handler(thread!!.looper)
        // Keep memory use bounded on mid-range phones; never retain full-resolution frames unnecessarily.
        val targetSize = CaptureSizing.fit(width, height, MAX_CAPTURE_DIMENSION)
        val captureWidth = targetSize.width
        val captureHeight = targetSize.height
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowPadding = plane.rowStride - pixelStride * width
                val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(plane.buffer)
                val bitmap = Bitmap.createBitmap(padded, 0, 0, width, height)
                padded.recycle()
                val scaled = if (captureWidth != width || captureHeight != height)
                    Bitmap.createScaledBitmap(bitmap, captureWidth, captureHeight, true) else bitmap
                if (scaled !== bitmap) bitmap.recycle()
                clearCachedCaptures()
                val file = File(cacheDir, "aura_screen_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 72, it) }
                scaled.recycle()
                sendResult(file.absolutePath, null)
            } catch (e: Exception) {
                sendResult(null, "پردازش تصویر صفحه ناموفق بود: ${e.message ?: "خطای تصویر"}")
            } finally { image.close(); stopSelf() }
        }, handler)
        display = projection?.createVirtualDisplay("AURA-screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
    }

    private fun sendResult(path: String?, error: String?) {
        sendBroadcast(Intent(ACTION_CAPTURE_RESULT).setPackage(packageName).apply {
            putExtra(EXTRA_PATH, path); putExtra(EXTRA_ERROR, error)
        })
    }

    override fun onDestroy() {
        reader?.close(); display?.release(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun clearCachedCaptures() {
        cacheDir.listFiles()?.filter { it.name.startsWith("aura_screen_") && it.extension == "jpg" }?.forEach { it.delete() }
    }

    companion object {
        const val MAX_CAPTURE_DIMENSION = 1440
        const val ACTION_CAPTURE_RESULT = "com.aura.ai.SCREEN_CAPTURE_RESULT"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_PATH = "capture_path"
        const val EXTRA_ERROR = "capture_error"
    }
}
