package com.aura.ai.ai

import android.content.Context

/** Model IDs are user-configurable and stored locally per provider. */
object ModelCatalog {
    const val OPENAI_DEFAULT = "gpt-4o-mini"
    const val GEMINI_DEFAULT = "gemini-2.0-flash"
    const val CLAUDE_DEFAULT = "claude-3-5-haiku-latest"

    fun defaultFor(provider: String): String = when (provider) {
        "OpenAI" -> OPENAI_DEFAULT
        "Gemini" -> GEMINI_DEFAULT
        "Claude" -> CLAUDE_DEFAULT
        else -> throw IllegalArgumentException("ارائه‌دهنده ناشناخته است.")
    }

    fun get(context: Context, provider: String): String =
        context.getSharedPreferences("aura_model_catalog", Context.MODE_PRIVATE)
            .getString(key(provider), defaultFor(provider)) ?: defaultFor(provider)

    fun save(context: Context, provider: String, modelId: String) {
        val normalized = modelId.trim()
        require(isValidModelId(normalized)) {
            "شناسه مدل نامعتبر است؛ فقط حروف انگلیسی، عدد و . _ : - مجاز است."
        }
        context.getSharedPreferences("aura_model_catalog", Context.MODE_PRIVATE)
            .edit().putString(key(provider), normalized).apply()
    }

    fun isValidModelId(modelId: String): Boolean = modelId.matches(Regex("[A-Za-z0-9._:-]{2,100}"))

    private fun key(provider: String): String = when (provider) {
        "OpenAI" -> "openai_model"
        "Gemini" -> "gemini_model"
        "Claude" -> "claude_model"
        else -> throw IllegalArgumentException("ارائه‌دهنده ناشناخته است.")
    }
}
