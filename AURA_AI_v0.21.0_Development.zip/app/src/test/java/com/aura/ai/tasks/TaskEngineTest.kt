package com.aura.ai.tasks

import org.junit.Assert.*
import org.junit.Test

class TaskEngineTest {
    @Test fun classifiesActionRisk() {
        val plan = TaskEngine.createPlan("پایین برو سپس روی تنظیمات بزن")
        assertNull(plan.blockedReason)
        assertEquals(TaskRisk.LOW, plan.steps[0].risk)
        assertEquals(TaskRisk.MODERATE, plan.steps[1].risk)
        assertTrue(plan.planId.isNotBlank())
    }

    @Test fun rejectsOverlongTypedText() {
        val plan = TaskEngine.createPlan("بنویس ${"الف".repeat(501)}")
        assertNotNull(plan.blockedReason)
        assertTrue(plan.steps.isEmpty())
    }

    @Test fun rejectsAmbiguousUnsupportedCommands() {
        val plan = TaskEngine.createPlan("برایم حساب کاربری بساز")
        assertNotNull(plan.blockedReason)
        assertTrue(plan.steps.isEmpty())
    }
}
