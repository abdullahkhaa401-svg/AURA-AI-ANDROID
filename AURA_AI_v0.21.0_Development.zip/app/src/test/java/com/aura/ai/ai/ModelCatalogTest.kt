package com.aura.ai.ai

import org.junit.Assert.*
import org.junit.Test

class ModelCatalogTest {
    @Test fun acceptsCommonModelIdentifiers() {
        assertTrue(ModelCatalog.isValidModelId("gpt-4o-mini"))
        assertTrue(ModelCatalog.isValidModelId("gemini-2.5-flash"))
        assertTrue(ModelCatalog.isValidModelId("claude-sonnet-4-5"))
    }

    @Test fun rejectsBlankAndUnsafeIdentifiers() {
        assertFalse(ModelCatalog.isValidModelId(""))
        assertFalse(ModelCatalog.isValidModelId("model name"))
        assertFalse(ModelCatalog.isValidModelId("model?key=secret"))
        assertFalse(ModelCatalog.isValidModelId("x"))
    }
}
