package com.aura.ai.tasks

import org.junit.Assert.*
import org.junit.Test

class AiTaskPlannerTest {
    @Test fun acceptsOnlyKnownSafeActions() {
        val plan = AiTaskPlanner.parse("صفحه را پایین ببر", """{"steps":[{"action":"SCROLL","argument":"","description":"پایین رفتن"}]}""")
        assertNull(plan.blockedReason)
        assertEquals(1, plan.steps.size)
        assertEquals(TaskAction.SCROLL, plan.steps[0].action)
    }

    @Test fun rejectsSensitiveButtonEvenIfAiSuggestsIt() {
        val plan = AiTaskPlanner.parse("روی ادامه بزن", """{"steps":[{"action":"CLICK_TEXT","argument":"پرداخت","description":"پرداخت"}]}""")
        assertNotNull(plan.blockedReason)
        assertTrue(plan.steps.isEmpty())
    }

    @Test fun rejectsUnknownActionAndTooManySteps() {
        val unknown = AiTaskPlanner.parse("کار", """{"steps":[{"action":"DELETE","argument":"","description":"حذف"}]}""")
        assertNotNull(unknown.blockedReason)
        val many = (1..6).joinToString(",") { "{\"action\":\"BACK\",\"argument\":\"\",\"description\":\"back\"}" }
        val tooMany = AiTaskPlanner.parse("کار", "{\"steps\":[$many]}")
        assertNotNull(tooMany.blockedReason)
    }

    @Test fun sensitiveOriginalRequestIsBlockedBeforeParsing() {
        val plan = AiTaskPlanner.parse("برایم پرداخت انجام بده", """{"steps":[{"action":"BACK","argument":"","description":"بازگشت"}]}""")
        assertNotNull(plan.blockedReason)
        assertTrue(plan.steps.isEmpty())
    }
}
