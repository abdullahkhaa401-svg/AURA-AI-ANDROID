package com.aura.ai.tasks

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class TaskRiskPolicyTest {
    @Test fun blocksFinancialAndDestructiveRequests() {
        assertNotNull(TaskRiskPolicy.blockedRequestReason("پرداخت را انجام بده"))
        assertNotNull(TaskRiskPolicy.blockedRequestReason("این فایل را حذف کن"))
        assertNotNull(TaskRiskPolicy.blockedRequestReason("کد تأیید را وارد کن"))
    }

    @Test fun blocksSensitiveButtonLabels() {
        assertNotNull(TaskRiskPolicy.blockedClickReason("ارسال"))
        assertNotNull(TaskRiskPolicy.blockedClickReason("Pay now"))
        assertNull(TaskRiskPolicy.blockedClickReason("تنظیمات"))
    }

    @Test fun blocksAdditionalHighImpactActions() {
        assertNotNull(TaskRiskPolicy.blockedRequestReason("به این شماره تماس بگیر"))
        assertNotNull(TaskRiskPolicy.blockedRequestReason("این فایل را share کن"))
        assertNotNull(TaskRiskPolicy.blockedClickReason("تماس"))
        assertNotNull(TaskRiskPolicy.blockedClickReason("Share"))
    }

    @Test fun blocksSecretsButAllowsOrdinaryText() {
        assertTrue(TaskRiskPolicy.isSensitiveText("رمز عبور 1234"))
        assertTrue(TaskRiskPolicy.isSensitiveText("شماره کارت 1234"))
        assertFalse(TaskRiskPolicy.isSensitiveText("سلام، حالت چطور است؟"))
    }
}
