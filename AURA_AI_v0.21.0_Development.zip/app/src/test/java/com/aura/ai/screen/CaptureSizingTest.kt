package com.aura.ai.screen

import org.junit.Assert.assertEquals
import org.junit.Test

class CaptureSizingTest {
    @Test fun keepsSmallFramesAtOriginalSize() {
        assertEquals(CaptureSizing.Size(720, 1280), CaptureSizing.fit(720, 1280))
    }
    @Test fun scalesLargeFramesWithoutChangingAspectRatioMaterially() {
        val size = CaptureSizing.fit(1440, 3200)
        assertEquals(648, size.width)
        assertEquals(1440, size.height)
    }
    @Test fun handlesInvalidDimensionsSafely() {
        assertEquals(CaptureSizing.Size(1, 1), CaptureSizing.fit(0, -4))
    }
}
